# LAB1 Kalman Filter / SLAM
# 68340700410 Phattanarat
Assignment: https://github.com/tanakon-apit/FRA532_LAB

## Contents
[Trajectories](#trajectories)
- [Wheel odometry](#wheel-odometry)
- [EKF odometry](#ekf-odometry)
- [IPC odometry](#wheeipc-odometry)
- [SLAM pose ](#slam-pose-output)

[2D maps](#2d-maps)

[Discussion](#discussion)


## Trajectories

### Wheel odometry
- ref: [diffdrive odometry](https://robotics.caltech.edu/wiki/images/d/d5/DiffDriveOdometry.pdf)
![Diffdrive model](images/diffdrive.png)
### EKF odometry

### IPC odometry

### SLAM pose output


## 2D maps


## Discussion
 
