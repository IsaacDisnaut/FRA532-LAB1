import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

def generate_launch_description():

    launch_description = LaunchDescription()

    package_name = "lab1"
    rviz_path = os.path.join(get_package_share_directory(package_name), "rviz", "config.rviz")
    
    seq_ns = ['seq00', 'seq01', 'seq02']
    for seq in seq_ns:
        bag_path = os.path.join(os.path.expanduser("~"), "mobile_robot", "FRA532_LAB1_DATASET", f"fibo_floor3_{seq}")
        bag_play = ExecuteProcess(
            cmd=['ros2', 'bag', 'play', bag_path, '--clock',
                 '--topics', '/joint_states', '/imu', '/scan',
                 '--remap', f'/joint_states:=/{seq}/joint_states',
                 '--remap', f'/imu:=/{seq}/imu',
                 '--remap', f'/scan:=/{seq}/scan',
                ],
            output='screen'
        )

        odom_node = Node(
            package=package_name,
            executable=f'ekf_odom.py',
            name=f'ekf_odom_node',
            namespace=seq,
            output='screen'
        )
        
        path_node = Node(
            package=package_name,
            executable='path.py',
            name='path_node',
            namespace=seq,
            output='screen'
        )
        
        launch_description.add_action(bag_play)
        launch_description.add_action(odom_node)
        launch_description.add_action(path_node)

    rviz = ExecuteProcess(
        cmd=['rviz2', '-d', rviz_path],
        output='screen',
    )
    launch_description.add_action(rviz) 


    return launch_description