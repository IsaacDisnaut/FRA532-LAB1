import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    launch_description = LaunchDescription()

    seq_arg = DeclareLaunchArgument(
        'seq',
        default_value='00',
        description='Bag sequence number (e.g., 00, 01, 02)'
    )

    package_name = "lab1"
    rviz_path = os.path.join(get_package_share_directory(package_name), "rviz", "ekf.rviz")
    use_sim_time = True
    seq = LaunchConfiguration('seq')
    bag_path = [os.path.join(os.path.expanduser("~"), "mobile_robot", "FRA532_LAB1_DATASET"), '/fibo_floor3_seq', seq]
        
    bag_play = ExecuteProcess(
        cmd=['ros2', 'bag', 'play', bag_path, '--clock',],
        output='screen'
    )

    odom_node = Node(
        package=package_name,
        executable='ekf_odom.py',
        name=f'ekf_odom_node',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}]
    )
        
    path_node = Node(
        package=package_name,
        executable='path.py',
        name=f'path_node',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}]
    )
    
    rviz = ExecuteProcess(
        cmd=['rviz2', '-d', rviz_path, '--ros-args', '-p', 'use_sim_time:=true'],
        output='screen',
    )

    launch_description.add_action(seq_arg)
    launch_description.add_action(bag_play)
    launch_description.add_action(odom_node)
    launch_description.add_action(path_node)
    launch_description.add_action(rviz)

    return launch_description