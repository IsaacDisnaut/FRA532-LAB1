#!/usr/bin/python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState, Imu
from nav_msgs.msg import Odometry
from tf_transformations import quaternion_from_euler
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
import numpy as np
from math import sin, cos, atan2


x = np.array([0.0, 0.0, 0.0, 0.0, 0.0])    # x, y, yaw, v, yaw_rate
u = np.array([0.0, 0.0])         # angle_left, angle_right
w = 0.16/2                       # half distance between wheels   
rho = 0.066/2                    # wheel radius

class wheelOdomNode(Node):
    def __init__(self):
        super().__init__('wheel_odom_node')
        self.dt = 1/20
        self.first_msg = True
        self.u_o = np.array([0.0, 0.0])
        self.x_o = np.array([0.0, 0.0, 0.0, 0.0, 0.0])
        self.tf_broadcaster = TransformBroadcaster(self)
        self.create_subscription(JointState, '/joint_states', self.joint_state_callback, 10)
        self.create_timer(self.dt, self.timer_callback)
        self.odom_publisher = self.create_publisher(Odometry, 'odom', 10)
        self.get_logger().info("wheel_odom_node: begin")


    def joint_state_callback(self, msg: JointState):
        u[0] = msg.position[0]
        u[1] = -msg.position[1]
        if self.first_msg:
            self.u_o = u.copy()
            self.first_msg = False


    def timer_callback(self):
        delta1 = u[0] - self.u_o[0]
        delta2 = u[1] - self.u_o[1]
        x[0] = self.x_o[0] + 0.5*rho*(delta2 - delta1)*cos(self.x_o[2]) # x
        x[1] = self.x_o[1] + 0.5*rho*(delta2 - delta1)*sin(self.x_o[2]) # y
        yaw = self.x_o[2] + (0.5*rho/w)*-(delta2 + delta1)              # yaw
        x[2] = atan2(sin(yaw), cos(yaw))                                # normalize to [-pi, pi]
        self.u_o = u.copy()
        self.x_o = x.copy()
        self.pub_odom()


    def pub_odom(self):
        msg = Odometry()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'odom'
        msg.child_frame_id = '/base_link'
        # Set pose
        msg.pose.pose.position.x = -x[0]
        msg.pose.pose.position.y = -x[1]
        q = quaternion_from_euler(0, 0, x[2])
        msg.pose.pose.orientation.x = q[0]
        msg.pose.pose.orientation.y = q[1]
        msg.pose.pose.orientation.z = q[2]
        msg.pose.pose.orientation.w = q[3]
        self.odom_publisher.publish(msg)
        self.publish_tf(msg)

    
    def publish_tf(self, odom_msg: Odometry):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'odom'
        t.child_frame_id = '/base_link'
        t.transform.translation.x = odom_msg.pose.pose.position.x
        t.transform.translation.y = odom_msg.pose.pose.position.y
        t.transform.rotation.x = odom_msg.pose.pose.orientation.x
        t.transform.rotation.y = odom_msg.pose.pose.orientation.y
        t.transform.rotation.z = odom_msg.pose.pose.orientation.z
        t.transform.rotation.w = odom_msg.pose.pose.orientation.w
        self.tf_broadcaster.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = wheelOdomNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__=='__main__':
    main()
