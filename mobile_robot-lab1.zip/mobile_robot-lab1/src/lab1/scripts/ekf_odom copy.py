#!/usr/bin/python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState, Imu
from nav_msgs.msg import Odometry
from tf_transformations import euler_from_quaternion, quaternion_from_euler
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
import numpy as np
from math import sin, cos, sqrt

r = 0.033 # wheel radius
b = 0.16  # distance between wheels

# porcess noise covariance
Q = np.diag([0.001, 0.001, 0.001, 0.001, 0.001]) # x, y, theta, v, w

# measurement noise covariance
R_imu = np.diag([0.1, 0.1])                 # theta, w
R_odom = np.diag([0.05, 0.05])              # wR, wL

def diffDriveModel(xEst, dt, u):
    wR = u[0]   # right wheel angular velocity
    wL = u[1]   # left wheel angular velocity
    x  = xEst[0]
    y  = xEst[1]
    theta = xEst[2]
    v  = xEst[3]
    w  = xEst[4]

    xN = x + v * cos(theta) * dt
    yN = y + v * sin(theta) * dt
    thetaN = theta + w * dt
    vN = 0.5 * r * (wR + wL)
    wN = (r / b) * (wR - wL)
    return np.array([xN, yN, thetaN, vN, wN])

def jacobian_F(xEst, dt):
    theta = xEst[2]
    v = xEst[3]

    F = np.eye(5)
    F[0,2] = -v * sin(theta) * dt
    F[0,3] = cos(theta) * dt
    F[1,2] = v * cos(theta) * dt
    F[1,3] = sin(theta) * dt
    F[2,4] = dt
    return F

def ekf_predict(xEst, PEst, u, dt):
    F = jacobian_F(xEst, dt)
    xPred = diffDriveModel(xEst, dt, u)
    PPred = F @ PEst @ F.T + Q
    return xPred, PPred

def ekf_update_imu(xPred, PPred, z):
    H = np.zeros((2, 5))
    H[0,2] = 1.0   
    H[1,4] = 1.0  
    zN = H @ xPred
    y = z - zN
    S = H @ PPred @ H.T + R_imu
    K = PPred @ H.T @ np.linalg.inv(S)
    xUpd = xPred + K @ y
    PUpd = (np.eye(len(xPred)) - K @ H) @ PPred
    return xUpd, PUpd

# def ekf_update_odom(xPred, PPred, z):
#     s = sqrt(xPred[0]**2 + xPred[1]**2) + 1e-9
#     H = (1/r)*np.array([[xPred[0]/s, xPred[1]/s, (1-2*b)/2, 0, 0],
#                         [xPred[0]/s, xPred[1]/s, (2*b-1)/2, 0, 0],
#                         [0, 0, 0, 1, b/2], 
#                         [0, 0, 0, 1, -b/2]])
#     zN = H @ xPred    
#     y = z - zN
#     S = H @ PPred @ H.T + R_odom
#     K = PPred @ H.T @ np.linalg.inv(S)
#     xUpd = xPred + K @ y
#     PUpd = (np.eye(len(xPred)) - K @ H) @ PPred
#     return xUpd, PUpd

def ekf_update_odom(xPred, PPred, z):
    H = np.array([[0, 0, 0, 2, b],
                  [0, 0, 0, 2, -b]])/r
    zN = H @ xPred
    y = z - zN
    S = H @ PPred @ H.T + R_odom
    K = PPred @ H.T @ np.linalg.inv(S)
    xUpd = xPred + K @ y
    PUpd = (np.eye(len(xPred)) - K @ H) @ PPred
    return xUpd, PUpd

class EKFOdomNode(Node):
    def __init__(self):
        super().__init__('ekf_odom_node')
        self.dt = 1/20 
        self.z_wheel = None  # thetaR, thetaL, wR, wL
        self.z_imu = None    # theta, w
        self.x = np.zeros(5)        # x, y, theta, v, w
        self.P = np.eye(5) * 0.0001 # initial covariance
        self.wheelAvai = False
        self.imuAvai = False

        self.create_subscription(JointState, '/joint_states', self.joint_state_callback, 10)
        self.create_subscription(Imu, '/imu', self.imu_callback, 10)
        self.create_timer(self.dt, self.timer_callback)
        self.odom_publisher = self.create_publisher(Odometry, 'odom', 10)
        self.tf_broadcaster = TransformBroadcaster(self)

        self.get_logger().info("ekf odom: begin")

    def joint_state_callback(self, msg: JointState):
        wL = msg.velocity[0]
        wR = msg.velocity[1]
        self.z_wheel = np.array([wR, wL])
        self.wheelAvai = True

    def imu_callback(self, msg: Imu):
        q = msg.orientation
        (_, _, theta) = euler_from_quaternion([q.x, q.y, q.z, q.w])
        w = msg.angular_velocity.z
        self.z_imu = np.array([theta, w])
        self.imuAvai = True
        
    def timer_callback(self):
        if self.z_wheel is not None:
            u = np.array([self.z_wheel[0], self.z_wheel[1]])
            self.x, self.P = ekf_predict(self.x, self.P, u, self.dt) # (xEst, PEst, u, dt)
            if self.imuAvai and self.z_imu is not None:
                self.x, self.P = ekf_update_imu(self.x, self.P, self.z_imu)     # (xPred, PPred, z)
                self.imuAvai = False
            if self.wheelAvai:
                self.x, self.P = ekf_update_odom(self.x, self.P, self.z_wheel)  # (xPred, PPred, z)
                self.wheelAvai = False
        self.pub_odom()

    def pub_odom(self):
        msg = Odometry()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'odom'
        msg.child_frame_id = 'base_link'
        # Set pose
        msg.pose.pose.position.x = self.x[0]
        msg.pose.pose.position.y = self.x[1]
        q = quaternion_from_euler(0, 0, self.x[2])
        msg.pose.pose.orientation.x = q[0]
        msg.pose.pose.orientation.y = q[1]
        msg.pose.pose.orientation.z = q[2]
        msg.pose.pose.orientation.w = q[3]
        # Set twist
        msg.twist.twist.linear.x = self.x[3]
        msg.twist.twist.angular.z = self.x[4]
        self.odom_publisher.publish(msg)
        self.publish_tf(msg)

    def publish_tf(self, odom_msg: Odometry):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_link'
        t.transform.translation.x = odom_msg.pose.pose.position.x
        t.transform.translation.y = odom_msg.pose.pose.position.y
        t.transform.rotation.x = odom_msg.pose.pose.orientation.x
        t.transform.rotation.y = odom_msg.pose.pose.orientation.y
        t.transform.rotation.z = odom_msg.pose.pose.orientation.z
        t.transform.rotation.w = odom_msg.pose.pose.orientation.w
        self.tf_broadcaster.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = EKFOdomNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__=='__main__':
    main()
