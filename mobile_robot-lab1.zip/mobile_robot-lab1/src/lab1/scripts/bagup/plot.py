#!/usr/bin/python3

import os
import matplotlib.pyplot as plt
import pandas as pd

# Load the CSV files
s00_data = pd.read_csv(os.path.expanduser('~/mobile_robot/result/s00_wheelV2.csv'))
# s01_data = pd.read_csv(os.path.expanduser('~/mobile_robot/result/s01_wheel.csv'))
# s02_data = pd.read_csv(os.path.expanduser('~/mobile_robot/result/s02_wheel.csv'))

# Create the plot
plt.figure(figsize=(10, 8))

# Plot each dataset
plt.plot(s00_data['/robot_pose/x'], s00_data['/robot_pose/y'], 
         color='red', linewidth=3, label='s00')
# plt.plot(s01_data['/robot_pose/x'], s01_data['/robot_pose/y'], 
#          color='green', linewidth=3, label='s01')
# plt.plot(s02_data['/robot_pose/x'], s02_data['/robot_pose/y'], 
#          color='blue', linewidth=3, label='s02')

# Set labels and title
plt.xlabel('x(m)', fontsize=12)
plt.ylabel('y(m)', fontsize=12)
plt.title('wheel odometry comparision', fontsize=14)

# Add legend and grid
plt.legend()
plt.grid(True)

# Make axes equal for proper visualization
plt.axis('equal')

# Show the plot
plt.tight_layout()
plt.show()
