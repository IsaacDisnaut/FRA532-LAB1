#!/usr/bin/python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState, Imu
from nav_msgs.msg import Odometry
from tf_transformations import euler_from_quaternion, quaternion_from_euler
import numpy as np
from math import sin, cos

r = 0.033 # wheel radius
b = 0.16  # distance between wheels

def diffDriveModel(xEst, dt, u):
    wL = u[0]   # left wheel angular velocity
    wR = u[1]   # right wheel angular velocity
    x  = xEst[0]
    y  = xEst[1]
    theta = xEst[2]
    v  = xEst[3]
    w  = xEst[4]

    xN = x + v * cos(theta) * dt
    yN = y + v * sin(theta) * dt
    thetaN = theta + w * dt
    vN = 0.5 * r * (wR + wL)
    wN = (r / b) * (wR - wL)
    return np.array([xN, yN, thetaN, vN, wN])

class wheelOdomNode(Node):
    def __init__(self):
        super().__init__('wheel_odom_node')
        self.dt = 1/20 
        self.z_wheel = np.zeros(2)  # wL, wR
        self.yaw_rate = 0.0
        self.x = np.zeros(5)        # x, y, theta, v, w
        self.wheelAvai = False

        self.create_subscription(JointState, 'joint_states', self.joint_state_callback, 10)
        self.create_subscription(Imu, 'imu', self.imu_callback, 10)
        self.create_timer(self.dt, self.timer_callback)
        self.odom_publisher = self.create_publisher(Odometry, 'odom', 10)

        self.get_logger().info("wheel_odom_node: begin")

    def joint_state_callback(self, msg: JointState):
        wL = msg.velocity[0]
        wR = msg.velocity[1]
        self.z_wheel = np.array([wL, wR])
        self.wheelAvai = True
    def imu_callback(self, msg: Imu):
        self.yaw_rate = msg.angular_velocity.z

    def timer_callback(self):
        if self.wheelAvai:
            self.x = diffDriveModel(self.x, self.dt, self.z_wheel)
            self.wheelAvai = False
        self.pub_odom()

    def pub_odom(self):
        msg = Odometry()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'odom'
        msg.child_frame_id = 'base_link'
        
        # Set pose
        msg.pose.pose.position.x = self.x[0]
        msg.pose.pose.position.y = self.x[1]
        q = quaternion_from_euler(0, 0, self.x[2])
        msg.pose.pose.orientation.x = q[0]
        msg.pose.pose.orientation.y = q[1]
        msg.pose.pose.orientation.z = q[2]
        msg.pose.pose.orientation.w = q[3]
        
        # Set twist
        msg.twist.twist.linear.x = self.x[3]
        msg.twist.twist.angular.z = self.x[4]
        
        self.odom_publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = wheelOdomNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__=='__main__':
    main()
