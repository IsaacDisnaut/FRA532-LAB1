#!/usr/bin/python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry, Path

class PathNode(Node):
    def __init__(self):
        super().__init__('path_node')
        self.path = Path()
        self.path_publisher = self.create_publisher(Path, 'path', 10)
        self.create_subscription(Odometry, 'odom', self.odom_callback, 10)
        self.get_logger().info('path_node: begin')
    

    def odom_callback(self, msg: Odometry):
        self.publish_path(msg)


    def publish_path(self, odom_msg: Odometry):
        pose = PoseStamped()
        pose.header.stamp = odom_msg.header.stamp
        pose.header.frame_id = odom_msg.header.frame_id
        pose.pose.position.x = odom_msg.pose.pose.position.x
        pose.pose.position.y = odom_msg.pose.pose.position.y
        pose.pose.orientation.x = odom_msg.pose.pose.orientation.x
        pose.pose.orientation.y = odom_msg.pose.pose.orientation.y
        pose.pose.orientation.z = odom_msg.pose.pose.orientation.z
        pose.pose.orientation.w = odom_msg.pose.pose.orientation.w

        self.path.header.stamp = odom_msg.header.stamp
        self.path.header.frame_id = odom_msg.header.frame_id
        self.path.poses.append(pose)
        self.path_publisher.publish(self.path)

def main(args=None):
    rclpy.init(args=args)
    node = PathNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
